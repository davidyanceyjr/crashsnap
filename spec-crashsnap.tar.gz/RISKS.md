# RISKS.md

## Retention misconfiguration

Risk:

- The product now has approved recommended retention values and explicit opt-in pruning.
- Implementation could still accidentally delete evidence if it treats documented recommendations as automatic active policy.

Mitigation:

- Keep the distinction between recommended retention values and active automatic pruning explicit.
- Require operator configuration before automatic prune behavior is enabled.

## Over-broad initial scope

Risk:

- `README.md` currently describes a wide surface area: run, attach, observe, core, service, report, inspect, diff, bundle, verify, doctor, config, schema, and prune workflows, plus report formats, redaction, bundle signing, container context, and systemd integration.
- A first implementation could fail by treating all described capabilities as equally in-scope.

Mitigation:

- Preserve the full planned command surface in the canonical docs.
- Separate phased implementation subsets explicitly in the implementation plan.

## Local data exposure risk

Risk:

- The product now explicitly allows local unredacted handling through operator action.
- Implementation could still expose sensitive data too broadly if explicit local-only guardrails are weak.

Mitigation:

- Keep local-only and explicit-unredacted behavior visible in the canonical and implementation-facing docs.
- Keep local-only and explicit-unredacted behavior visible in the canonical and implementation-facing docs.

## Environment variability

Risk:

- The product requires systemd support, may optionally support containers, and must not assume elevated privileges.
- Implementation can still fail if it silently assumes root-like access instead of handling permission limits explicitly.

Mitigation:

- Preserve systemd as mandatory in the implementation plan.
- Require graceful degradation and explicit collector-failure reporting under restricted permissions.

## False completeness

Risk:

- A polished document set could imply the product is safer than the implementation if operator opt-in pruning is implemented incorrectly.

Mitigation:

- Keep the retention decision and its opt-in semantics explicit in `README.md`, `DECISIONS.md`, and `docs/IMPLEMENTATION_PLAN.md`.
- Verify that the handoff package states implementation-ready product truth without implying automatic deletion.
