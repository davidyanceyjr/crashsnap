# DECISIONS.md

## D-001: Canonical product source document

Status: DECIDED

`README.md` is the canonical narrative product definition for now.

Rationale:

- `README.md` already contains the only concrete end-user product narrative in the repository.
- `PRODUCT_BRIEF.md` remains a blank template.
- Supporting documents must align to `README.md` until a later decision replaces it.

## D-002: This session normalizes instead of expanding scope

Status: DECIDED

This first session does not add new product capabilities beyond what `README.md` already claims. It translates the existing narrative into implementation-facing documents and records unresolved product-definition gaps explicitly.

Rationale:

- The repository already contains a detailed CLI specification.
- The implementation-facing package was missing, but inventing additional product behavior would violate the authoring role.
- Several major product choices remain unresolved and must be surfaced as questions, not silently decided here.

## D-003: Product identity

Status: DECIDED

The public product and command name is `crashsnap`.

Rationale:

- The user explicitly chose `crashsnap`.
- The canonical document and supporting docs must stop referring to `gdbsnap` as the production name.

## D-004: Command scope

Status: DECIDED

All commands currently described in `README.md` remain part of the planned product surface, but implementation may deliver them in subsets rather than one all-at-once release.

Rationale:

- The user explicitly approved planning for the full command set in `README.md`.
- The user explicitly rejected the assumption that all commands must ship in a single implementation slice.

## D-005: Data handling and sharing posture

Status: DECIDED

The product is local-only in scope. Unredacted output is allowed only through explicit operator action.

Rationale:

- The user explicitly scoped the product to local use.
- The user explicitly allowed unredacted handling when done explicitly.

## D-006: Environment scope

Status: DECIDED

Systemd support is required. Container support is optional, not mandatory. The product must not assume elevated privileges are available.

Interpretation recorded:

- "No privilege assumptions" is interpreted as: implementation must attempt collection with the permissions available to the current operator, degrade gracefully when required access is unavailable, and report missing privileges or blocked collectors explicitly.

Rationale:

- The user explicitly required systemd support.
- The user explicitly said containers are not mandatory.
- The privilege interpretation is the narrowest practical reading that does not invent elevated-access guarantees.

## D-007: Retention and prune defaults

Status: DECIDED

`crashsnap` ships with documented recommended retention values, but no active automatic pruning until the operator configures retention explicitly.

Approved recommended initial values:

- `max_age_days = 14`
- `max_total_size = "10GiB"`
- `max_snapshots = 50`

Operational rule:

- `prune` must not silently apply automatic retention policy unless the operator has explicitly configured retention.
- Manual cleanup may still be performed through explicit `prune` flags and should support `--dry-run`.

Rationale:

- Crash artifacts are evidence, so silent deletion is higher risk than over-retention.
- The user approved the recommended-value plus explicit-opt-in pruning model.
