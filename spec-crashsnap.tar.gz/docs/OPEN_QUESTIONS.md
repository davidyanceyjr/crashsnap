# OPEN_QUESTIONS.md

## Purpose

This file stores unresolved questions that implementation must be able to see.

Every open question must be answered, explicitly deferred, or carried as a documented non-blocking assumption.

## BLOCKING

No blocking questions currently recorded.

## NON-BLOCKING

No non-blocking questions currently recorded.

## Answered / historical

### AQ-001: Which document is canonical right now?

Answer:

- `README.md` is the canonical product source document until a later decision replaces it.

### AQ-002: What is the public product and command name?

Answer:

- The public product and command name is `crashsnap`.

### AQ-003: What is the command-scope posture?

Answer:

- All commands currently documented in `README.md` remain planned product surface.
- Implementation may deliver them in subsets rather than one all-at-once release.

### AQ-004: What is the data-handling and sharing posture?

Answer:

- The product is local-only in scope.
- Unredacted output is allowed only through explicit operator action.

### AQ-005: Which environment scope decisions are resolved?

Answer:

- Systemd support is required.
- Container support is optional, not mandatory.
- The product must not assume elevated privileges are available; it must degrade gracefully and report blocked collectors explicitly.

### AQ-006: What retention policy should local artifacts follow?

Answer:

- `crashsnap` ships with documented recommended retention values, but no active automatic pruning until the operator configures retention explicitly.
- Approved recommended initial values are `max_age_days = 14`, `max_total_size = "10GiB"`, and `max_snapshots = 50`.
- `prune` should be explicit and support `--dry-run`; documented recommendations must not be treated as silently active deletion behavior.
